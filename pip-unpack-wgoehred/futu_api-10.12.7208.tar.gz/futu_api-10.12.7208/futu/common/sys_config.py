# -*- coding: utf-8 -*-
import os
import sys
import traceback
from . import bytes_utf8, IS_PY2, str_utf8
from .constant import *
from .ft_logger import logger
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5 as Cipher_pkcs1
from Crypto import Random


class RunMode:
    DEFAULT = 'DEFAULT'
    STRATEGY = 'STRATEGY'


class SysConfig(object):
    IS_PROTO_ENCRYPT = False                # api通讯协议是否加密
    INIT_RSA_FILE = ''                      # 初始连接协议用到的rsa private key file
    TOKEN = ''                              # 初始连接协议用到的连接鉴权token
    RSA_OBJ = None                          # ras加解密对象
    PROTO_FMT = None                        # 协议格式
    CLINET_ID = None                        # Client标识
    CLIENT_VER = None                       # Client ver
    ALL_THREAD_DAEMON = False               # 是否所有产生的线程都是daemon线程
    RUN_MODE = RunMode.DEFAULT

    @classmethod
    def set_client_info(cls, client_id, client_ver):
        """
        ..  py:function:: set_client_info(cls, client_id, client_ver)

        设置调用api的客户端信息, 非必调接口

        :param client_id: str, 客户端标识
        :param client_ver: int, 客户端版本号
        :return: None

        :example:

        .. code:: python

         from futu import *
         SysConfig.set_client_info("MyFutuAPI", 0)
         quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
         quote_ctx.close()

        """

        SysConfig.CLINET_ID = client_id
        SysConfig.CLIENT_VER = client_ver

    @classmethod
    def get_client_id(cls):
        return SysConfig.CLINET_ID if SysConfig.CLINET_ID else DEFULAT_CLIENT_ID

    @classmethod
    def get_client_ver(cls):
        return SysConfig.CLIENT_VER if SysConfig.CLIENT_VER is not None else CLIENT_VERSION

    @classmethod
    def get_proto_fmt(cls):
        return SysConfig.PROTO_FMT if SysConfig.PROTO_FMT else DEFULAT_PROTO_FMT

    @classmethod
    def set_proto_fmt(cls, proto_fmt):
        """

        ..  py:function:: set_proto_fmt(cls, proto_fmt)

        设置通讯协议body格式, 目前支持Protobuf | Json两种格式, 非必调接口

        :param proto_fmt: ProtoFMT
        :return: None

        :example:

        .. code:: python

         from futu import *
         SysConfig.set_proto_fmt(ProtoFMT.Protobuf)
         quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
         quote_ctx.close()

        """
        fmt_list = [ProtoFMT.Protobuf, ProtoFMT.Json]

        if proto_fmt not in fmt_list:
            raise Exception("proto_fmt error")
        SysConfig.PROTO_FMT = proto_fmt

    @classmethod
    def enable_proto_encrypt(cls, is_encrypt):
        """
        ..  py:function:: enable_proto_encrypt(cls, is_encrypt)

        设置通讯协议是否加密, 网关客户端和api需配置相同的RSA私钥文件,在连接初始化成功后，网关会下发随机生成的AES 加密密钥

        :param is_encrypt: bool
        :return: None

        :example:

        .. code:: python

         from futu import *
         SysConfig.enable_proto_encrypt(True)
         SysConfig.set_init_rsa_file("conn_key.txt")   # rsa 私钥文件路径
         quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
         quote_ctx.close()

        """
        SysConfig.IS_PROTO_ENCRYPT = bool(is_encrypt)

    @classmethod
    def set_init_rsa_file(cls, file):
        """
        ..  py:function:: set_init_rsa_file(cls, file)

        设置RSA私钥文件, 格式为PKCS#1；支持1024/2048等位长（明文分块固定100，密文块随密钥自适应）

        :param file:  str, 文件路径
        :return: None

        :example:

        .. code:: python

         from futu import *
         SysConfig.enable_proto_encrypt(True)
         SysConfig.set_init_rsa_file("conn_key.txt")   # rsa 私钥文件路径
         quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
         quote_ctx.close()

        """
        SysConfig.INIT_RSA_FILE = str(file)
        SysConfig.RSA_OBJ = None
        RsaCrypt.CHIPPER = None
        RsaCrypt.RSA_KEY = None

    @classmethod
    def set_token(cls, token):
        """
        ..  py:function:: set_token(cls, token)

        设置连接鉴权token, 非必调接口; 不设置时初始连接不带token字段

        :param token: str, 连接鉴权token; 传None或空串表示不设置
        :return: None

        :example:

        .. code:: python

         from futu import *
         SysConfig.set_token("your_token")
         quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
         quote_ctx.close()

        """
        SysConfig.TOKEN = str(token) if token else ''

    @classmethod
    def get_token(cls):
        """
        :return: str , token for init connect protocol
        """
        return SysConfig.TOKEN

    @classmethod
    def get_init_rsa_obj(cls):
        """
        :return: str , private key for init connect protocol
        """

        if not SysConfig.RSA_OBJ:
            SysConfig._read_rsa_keys()

        return SysConfig.RSA_OBJ

    @classmethod
    def is_proto_encrypt(cls):
        """
        :return: bool
        """
        return SysConfig.IS_PROTO_ENCRYPT

    @classmethod
    def _read_rsa_keys(cls):
        file_path = SysConfig.INIT_RSA_FILE if SysConfig.INIT_RSA_FILE \
            else os.path.join(os.path.dirname(__file__), DEFAULT_INIT_PRI_KEY_FILE)

        try:
            f = open(file_path, 'rb')
            df = f.read()
            if type(df) is not str:
                df = str_utf8(df)

            rsa = RSA.importKey(df)
            pub_key = rsa.publickey().exportKey()
            if not pub_key:
                raise Exception("Illegal format of file content")

            SysConfig.RSA_OBJ = rsa

        except Exception as e:
            traceback.print_exc()
            err = sys.exc_info()[1]
            err_msg = "Fatal error occurred in getting proto key, detail:{}".format(err)
            logger.error(err_msg)
            raise Exception(err_msg)

    @classmethod
    def set_all_thread_daemon(cls, all_daemon):
        """
        设置是否所有内部创建的线程都是daemon线程
        :param all_daemon: bool
        :return:
        """
        SysConfig.ALL_THREAD_DAEMON = all_daemon

    @classmethod
    def get_all_thread_daemon(cls):
        return SysConfig.ALL_THREAD_DAEMON

    @classmethod
    def set_run_mode(cls, mode):
        cls.RUN_MODE = mode

    @classmethod
    def get_run_mode(cls):
        return cls.RUN_MODE

    @classmethod
    def enable_console_log(cls, enable):
        """
        设置是否屏蔽控制台log，注意需要在程序启动时设置以避免多线程问题
        :param enable: bool
        """
        logger.enable_console_log(enable)


class RsaCrypt(object):
    RANDOM_GENERATOR = Random.new().read
    CHIPPER = None
    RSA_KEY = None
    # 明文分块固定100（须 <= 最小支持钥长的 k-11；1024时上限117）
    PLAIN_BLOCK_SIZE = 100

    @classmethod
    def _ensure_cipher(cls):
        if cls.CHIPPER is None:
            cls.RSA_KEY = SysConfig.get_init_rsa_obj()
            cls.CHIPPER = Cipher_pkcs1.new(cls.RSA_KEY)
            # PKCS#1 v1.5 单次明文上限为 size_in_bytes()-11
            if cls.PLAIN_BLOCK_SIZE > cls.RSA_KEY.size_in_bytes() - 11:
                raise ValueError(
                    "RSA key too small for PLAIN_BLOCK_SIZE=%d (need at least %d-bit)"
                    % (cls.PLAIN_BLOCK_SIZE, (cls.PLAIN_BLOCK_SIZE + 11) * 8)
                )

    @classmethod
    def encrypt(cls, data):
        cls._ensure_cipher()

        if type(data) is not bytes:
            data = bytes_utf8(str(data))

        one_len = cls.PLAIN_BLOCK_SIZE
        ret_data = b''
        for i in range(0, len(data), one_len):
            ret_data += cls.CHIPPER.encrypt(data[i:i + one_len])
        return ret_data

    @classmethod
    def decrypt(cls, data):
        cls._ensure_cipher()

        # 密文块长随密钥自适应：1024→128，2048→256
        one_len = cls.RSA_KEY.size_in_bytes()
        ret_data = b''

        # python2下需转成str类型,否则异常
        if IS_PY2:
            data = str(data)

        if len(data) % one_len != 0:
            raise ValueError(
                "RSA ciphertext length %d is not multiple of key size %d"
                % (len(data), one_len)
            )

        for i in range(0, len(data), one_len):
            ret_data += cls.CHIPPER.decrypt(data[i:i + one_len], cls.RANDOM_GENERATOR)

        return ret_data


"""
test_str = 'futu api' * 32
dt_encrypt = RsaCrypt.encrypt(test_str)
print(dt_encrypt)
dt_decrypt = RsaCrypt.decrypt(dt_encrypt)
print(dt_decrypt)
"""

"""
from Crypto.Cipher import AES
from binascii import b2a_hex, a2b_hex

key = b'0123456789abcdef'
cryptor = AES.new(key, AES.MODE_ECB, key)

src = b'123'
len_src = len(src)
add = 16 - (len_src % 16)
src = src
src2 = src + (b'\0' * add)

dst = cryptor.encrypt(src2)
hex_dst = b2a_hex(dst)
print(hex_dst)

src3 = cryptor.decrypt(dst)
print("len={} decrypt={}".format(len(src3), src3))
"""





